<?php

namespace App\Http\Controllers;
use App\Models\Helthss;
use HasFactory;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;


class HelthController extends Controller
{
    public function helthcoverage()
    {
    return view('helth.helthcoverage');
    }
     public function formsubmit(Request $request)
    {
/*dd($request);*/

    $ua = $request->server('HTTP_USER_AGENT');
        $ip  =  $request->ip();
        $currenturl = url()->full();
    
 

        $xml="<?xml version=\"1.0\"?>
       <Request>
    <CampaignID>10</CampaignID>
    <VendorID>5</VendorID>
    <APIKey>377c02e0801e725e77c53c876cc2843a</APIKey>
    <TestMode>1</TestMode>
    <SubID>TestData</SubID>
    <xxTrustedFormCertUrl>".$request->xxTrustedFormCertUrl."</xxTrustedFormCertUrl>
    <UniversalLeadID>".$request->universal_leadid."</UniversalLeadID>
    <UserAgent>".$ua."</UserAgent>
    <IPAddress>".$ip."</IPAddress>
    <TCPAOptin>1</TCPAOptin>
    <TCPAText>By clicking “Get Quotes”, you provide your express written consent via electronic signature to be contacted for marketing purposes by one or more of our partner companies regarding their products and services at the phone number/email provided, including a wireless number if provided. Contact methods may include phone calls generated using automated dialing systems, artificial voice messaging, prerecorded voice messages, text messaging and/or email regardless of previous registration(s) on a federal or state Do Not Call registries or any internal opt-out/unsubscribe requests. Data rates may apply. You understand that consent is not a condition of purchase and is not required to get a quote. By clicking “Get Quotes” you confirm that you have read and agree to the Terms of Use and Privacy Policy of this website</TCPAText>
    <URL>".$currenturl."</URL>
    <FirstName>".$request->first_name."</FirstName>
    <LastName>".$request->last_name."</LastName>
    <Email>".$request->email."</Email>
    <HomePhone>2123456789</HomePhone>
    <Address>".$request->address."</Address>
    <City>".$request->city."</City>
    <State>".$request->state."</State>
    <Zip>".$request->zip."</Zip>
    <CurrentInsuranceCompany>Allstate Insurance</CurrentInsuranceCompany>
    <ExpirationDate>2023-08-18</ExpirationDate>
    <InsuredSince>2012-01-01</InsuredSince>
    <Applicants>
        <Applicant>
            <RelationshipToApplicant>1</RelationshipToApplicant>
            <Height>".$request->height."</Height>
            <Weight>".$request->weight."</Weight>
            <DOB>".$request->dob."</DOB>
            <Gender>".$request->gender."</Gender>
            <MedicalCondition>1,2,3</MedicalCondition>
        </Applicant>
    </Applicants>
</Request>
";

$response = Http::withHeaders(['Content-Type' => 'text/xml; charset=utf-8'])->send('POST', 'https://api.lostfallsllc.com/PingPost', [
            'body' => $xml,
        ]);

        $clean_xml = str_ireplace(['SOAP-ENV:', 'SOAP:'], '', $response);
        $cxml = simplexml_load_string($clean_xml);

      /* dd($cxml);*/
/*echo $res->getBody();
dd(454);*/

		 $helth = Helthss::create($request->all());
      return redirect()->back()->with('message', 'Thank you for submitting your form!');
	}
	public function index()
    {
    
        $products = Helthss::latest()->paginate(5);
         return view('helth.index',compact('products'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }
	
	 public function show($id)
    {
    	 $helthss = Helthss::find($id);
      return view('helth.show',compact('helthss'));
    } 
}
