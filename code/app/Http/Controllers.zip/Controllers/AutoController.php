<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Auto;
use App\Models\Automake;
use App\Models\Automodel;
use App\Models\Year;
 use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;

use App\Models\Autosubmodelmake;

class AutoController extends Controller
{
    public function autocoverage()
    {
         $automake = Year::get();
            $uniques = array();
            foreach ($automake as $c) {
            $uniques[$c->year] = $c; 
}

    return view('auto.autocoverage',compact('uniques'));
    }


   public function index()
    {
    
        $products = Auto::latest()->paginate(5);
       
         return view('auto.index',compact('products'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

 public function testing()
    {
         $automake = Year::get();
            $uniques = array();
            foreach ($automake as $c) {
            $uniques[$c->year] = $c; 
}
        
     
           
        return view('testing',compact('uniques'));
    } 

     public function testingsub(Request $request)
    {
    
          $automake = Year::where('year',$request->cat_id)->get();

                  $automodelmake = array();
            foreach ($automake as $c) {
            $automodelmake[$c->make] = $c; 
}
      return response()->json([
            'automodelmake' => $automodelmake
        ]);

      
        return view('testing',compact('automake'));
    } 

    public function autosubmit(Request $request)
    {
        
       $ua = $request->server('HTTP_USER_AGENT');
        $ip  =  $request->ip();
        $currenturl = url()->full();


$xml = "<?xml version=\"1.0\"?>
<Request>

    <CampaignID>4</CampaignID>
    <VendorID>4</VendorID>
    <APIKey>96f620edaa0d792de17a38a5df539046</APIKey>
    <TestMode>1</TestMode>
    <SubID>cascadeCoverage</SubID>
    <xxTrustedFormCertUrl>".$request->xxTrustedFormCertUrl."</xxTrustedFormCertUrl>
    <UniversalLeadID>".$request->universal_leadid."</UniversalLeadID>
    <UserAgent>".$ua."</UserAgent>
    <IPAddress>".$ip."</IPAddress>
    <TCPAOptin>1</TCPAOptin>
    <TCPAText>By clicking “Get Quotes”, you provide your express written consent via electronic signature to be contacted for marketing purposes by one or more of our partner companies regarding their products and services at the phone number/email provided, including a wireless number if provided. Contact methods may include phone calls generated using automated dialing systems, artificial voice messaging, prerecorded voice messages, text messaging and/or email regardless of previous registration(s) on a federal or state Do Not Call registries or any internal opt-out/unsubscribe requests. Data rates may apply. You understand that consent is not a condition of purchase and is not required to get a quote. By clicking “Get Quotes” you confirm that you have read and agree to the Terms of Use and Privacy Policy of this website.</TCPAText>
    <URL>".$currenturl."</URL>
    <FirstName>".$request->first_name."</FirstName>
    <LastName>".$request->last_name."</LastName>
    <Email>".$request->email."</Email>
    <HomePhone>2123456789</HomePhone>
    <Address>".$request->address."</Address>
    <City>".$request->city."</City>
    <State>".$request->state."</State>
    <Zip>".$request->zip."</Zip>
    <CurrentCoverageType>".$request->current_coverage_type."</CurrentCoverageType>
    <CurrentInsuranceCompany>".$request->current_insurance_company."</CurrentInsuranceCompany>
    <CurrentPolicyExpires>".$request->current_policy_expiry_date."</CurrentPolicyExpires>
    <InsuredSince>".$request->insured_Since."</InsuredSince>
    <RequestedUninsuredMotoristCover>".$request->uninsured_motorist_cover."</RequestedUninsuredMotoristCover>
 
    <RequestedCoverageType>".$request->coverage_type."</RequestedCoverageType>
 
    <Drivers>
        <Driver>
            <RelationshipToApplicant>".$request->relationship_to_applicant."</RelationshipToApplicant>
            <FirstName>".$request->first_name_relationship."</FirstName>
            <LastName>".$request->last_name_relationship."</LastName>
            <DOB>".$request->bod."</DOB>
            <MaritalStatus>".$request->marital_status."</MaritalStatus>
            <Gender>".$request->gender."</Gender>
            <LicenseStatus>".$request->license_status."</LicenseStatus>
            <LicenseState>".$request->license_state."</LicenseState>
        </Driver>
    </Drivers>
    <Vehicles>
        <Vehicle>
            <Year>".$request->year."</Year>
            <Make>".$request->make."</Make>
            <Model>".$request->model."</Model>
            <VIN>".$request->vin."</VIN>
        </Vehicle>
    </Vehicles>
</Request>"
                ;

         
/*dd($xml);*/
$response = Http::withHeaders(['Content-Type' => 'text/xml; charset=utf-8'])->send('POST', 'https://api.lostfallsllc.com/PingPost', [
            'body' => $xml,
        ]);

        $clean_xml = str_ireplace(['SOAP-ENV:', 'SOAP:'], '', $response);
        $cxml = simplexml_load_string($clean_xml);

       


/*echo $res->getBody();
dd(454);*/

        $dnclist = Auto::create($request->all());
        
       return redirect()->back()->with('message', 'Thank you for submitting your form!');

       
    } 


         public function testingsubsub(Request $request)
    {
        
        $automake = Year::where('make',$request->cat_id)->get();

                  $autosubmodelmake = array();
            foreach ($automake as $c) {
            $autosubmodelmake[$c->model] = $c; 
}
      return response()->json([
            'autosubmodelmake' => $autosubmodelmake
        ]);

    
    } 


    public function show($id)
    {
    	 $autoshow = Auto::find($id);
 
   /*	 dd($autoshow);*/
    	   
        return view('auto.show',compact('autoshow'));
    } 

}
