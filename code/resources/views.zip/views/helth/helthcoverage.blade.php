<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <!-- <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    /> -->

    <!-- Font-awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />

    <title>Cascade</title>

    <!-- Favicon -->
      <link
      rel="apple-touch-icon"
      sizes="180x180"
      href="{{ asset('public/images/apple-touch-icon.png')}}"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="32x32"
      href="{{ asset('public/images/favicon-32x32.png')}}"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="16x16"
      href="{{ asset('public/images/favicon-16x16.png')}}"
    />
    <link rel="manifest" href="images/site.webmanifest" />
    <meta name="msapplication-TileColor" content="#da532c" />
    <meta name="theme-color" content="#ffffff" />
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />

    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-1.9.0.js"></script>
    <script
      type="text/javascript"
      src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"
    ></script>
    <script
      type="text/javascript"
      src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"
    ></script>

    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
    />

    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    />

    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"
    />

    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"
    />

    <!-- External Css file -->
 <link rel="stylesheet" href="{{ asset('public/style.css')}}" />

        <style>
      .progress-bar {
        width: 100%;
        height: 20px;
        background-color: #b3b3df;
        border-radius: 15px;
        position: relative;
        margin-bottom: 20px;
      }

      .progress-bar__steps {
        display: flex;
        justify-content: space-between;
        position: absolute;
        top: 50%;
        left: 0;
        transform: translateY(-50%);
        width: 100%;
        height: 100%;
        padding: 0 10px;
      }

      .progress-bar__step {
        width: 20px;
        height: 20px;
        background-color: #384fe9;
        border-radius: 50%;
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 16px;
        color: #fff;
      }

      .progress-bar__step.active {
        background-color: rgb(8, 17, 44);
      }

      .progress-bar__step i {
        font-size: 12px;
      }

      .progress-bar__progress {
        height: 100%;
        background-color: rgb(99, 117, 198);
        border-radius: 15px;
        width: 0;
        transition: width 0.8s ease;
      }

      a.btn.btn-primary.next {
        color: #fff;
        background-color: #102870;
        border-color: #0a1a4d;
      }

      a.btn.btn-primary.previous {
        color: #fff;
        background-color: #102870;
        border-color: #0a1a4d;
      }
      select.form-control {
        background-image: linear-gradient(45deg, transparent 50%, gray 50%),
          linear-gradient(135deg, gray 50%, transparent 50%),
          radial-gradient(#ddd 70%, transparent 72%);
        background-position: calc(100% - 20px) calc(1em + 2px),
          calc(100% - 15px) calc(1em + 2px), calc(100% - 0.5em) 0.5em;
        background-size: 5px 5px, 5px 5px, 1.5em 1.5em;
        background-repeat: no-repeat;
      }
      label.col-lg-12.control-label {
        text-align: left;
        margin-bottom: 14px;
        margin-top: 14px;
      }
      form#myform {
        background: #fafafaeb;
        border: 0 none;
        border-radius: 0.5rem;
        box-sizing: border-box;
        width: 100%;
        margin: 0;
        padding-bottom: 20px;
        position: relative;
      }
      label.col-lg-4.control-label {
        float: left;
      }
      #personal_information,
      #company_information {
        display: none;
      }
      #personal_information,
      #company_information {
        display: none;
      }
      .navbar-expand-sm .navbar-collapse {
        display: contents !important;
        flex-basis: auto;
      }
      * {
        margin: 0;
        padding: 0;
      }

      html {
        height: 100%;
      }

      #heading {
        text-transform: uppercase;
        color: #673ab7;
        font-weight: normal;
      }

      #msform {
        text-align: center;
        position: relative;
        margin-top: 20px;
      }

      #msform fieldset {
        background: #fafafaeb;
        border: 0 none;
        border-radius: 0.5rem;
        box-sizing: border-box;
        width: 100%;
        margin: 0;
        padding-bottom: 20px;

        /*stacking fieldsets above each other*/
        position: relative;
      }

      .form-card {
        text-align: left;
      }

      /*Hide all except first fieldset*/
      #msform fieldset:not(:first-of-type) {
        display: none;
      }

      #msform input,
      #msform textarea {
        padding: 8px 15px 8px 15px;
        border: 1px solid #ccc;
        border-radius: 0px;
        margin-bottom: 25px;
        margin-top: 2px;
        width: 100%;
        box-sizing: border-box;
        font-family: montserrat;
        color: #2c3e50;
        background-color: white;
        font-size: 16px;
        letter-spacing: 1px;
      }

      #msform input:focus,
      #msform textarea:focus {
        -moz-box-shadow: none !important;
        -webkit-box-shadow: none !important;
        box-shadow: none !important;
        border: 1px solid #673ab7;
        outline-width: 0;
      }

      /*Next Buttons*/
      #msform .action-button {
        width: 100px;
        background: #112b75;
        font-weight: bold;
        color: white;
        border: 0 none;
        border-radius: 0px;
        cursor: pointer;
        padding: 10px 5px;
        margin: 10px 0px 10px 20px;
        float: left;
      }

      #msform .action-button:hover,
      #msform .action-button:focus {
        background-color: #311b92;
      }

      /*Previous Buttons*/
      #msform .action-button-previous {
        width: 100px;
        background: #616161;
        font-weight: bold;
        color: white;
        border: 0 none;
        border-radius: 0px;
        cursor: pointer;
        padding: 10px 5px;
        margin: 10px 5px 10px 0px;
        float: right;
      }

      #msform .action-button-previous:hover,
      #msform .action-button-previous:focus {
        background-color: #000000;
      }

      /*The background card*/
      .card {
        z-index: 0;
        border: none;
        position: relative;
        background-color: transparent;
      }

      /*FieldSet headings*/
      .fs-title {
        font-size: 23px;
        color: #000000ad !important;
        margin-bottom: 15px;
        font-weight: 500;
        text-align: left;
      }

      .purple-text {
        color: #673ab7;
        font-weight: normal;
      }

      /*Step Count*/
      .steps {
        font-size: 25px;
        color: gray;
        margin-bottom: 10px;
        font-weight: normal;
        text-align: right;
      }

      /*Field names*/
      .fieldlabels {
        text-align: left;
        color: #000000c2;
        font-weight: 500;
        font-size: 14px;
      }

      /*Icon progressbar*/
      

     
     

      /*Fit image in bootstrap div*/
      .fit-image {
        width: 100%;
        object-fit: cover;
      }
      .bb {
        text-align: right;
        font-size: 26px;
        font-weight: 700;
      }
      .aa {
        font-size: 65px;
        color: #0e2052;
        font-weight: 700;
        margin-left: 88px;
      }
      .cc {
        font-size: 60px;
        color: #0e2052;
        font-weight: 700;
        text-align: center;
      }
      .health {
        color: #0e2052;
        font-weight: 700;
      }

      @media screen and (max-width: 600px) {
        .aa {
          font-size: 25px !important;
          color: #0e2052;
          font-weight: 700;
          margin-left: 88px;
        }

        .bb {
          font-size: 18px;
          font-weight: 700;
          text-align: justify !important;
        }
        .cc {
          font-size: 30px;
          color: #0e2052;
          font-weight: 700;
          text-align: center;
          margin-top: 30px;
        }
        .xx {
          background-color: red !important;
        }
      }

      /* .xx{
    background-image:url('{{ asset('image/health-bg.jpg')}}');background-size:cover;background-repeat:no-repeat;} */

      #auto_coverage_background {
     background-image: url("{{ asset('public/images/health-bg.jpg') }}");
        background-size: cover;
        background-repeat: no-repeat;
        padding-top: 1rem;
        max-width: 100%;
        background-size: 100% 100%;
      }
    </style>
  </head>

  <body>
    <!-- Section one Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light mb-5">
      <div class="container-fluid" style="padding: 0 4rem" id="top-nav">
        <a class="navbar-brand" href="{{ url('/') }}">
          <img src="{{ asset('public/images/logo2.png') }}" alt="logo" class="logo-img img-fluid" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <!-- <a class="nav-link active" aria-current="page" href="#"></a> -->
            </li>
          </ul>
          <div class="d-flex">
            <ul class="navbar-nav me-4 mb-2 mb-lg-0">
              <li class="nav-item" style="margin-right: 10px">
               <a
                  class="nav-link active fs-5 fw-bold"
                  aria-current="page"
                  href="{{ route('auto-coverage') }}"
                  >Auto Coverage</a
                >
              </li>
              <li class="nav-item">
                <a class="nav-link active fs-5 fw-bold" href="{{ route('helth-coverage') }}"
                  >Health Coverage</a
                >
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!-- Section two -->
    <div class="container-fluid">
      <div class="row d-flex justify-content-evenly px-3">
          
          <div class="col-md-5 my-2">
          <img
            src="{{ asset('public/images/HEALTH-COVERAGE-PNG.png')}}"
            class="img-fluid d-none d-md-block"
            id="left-side2"
            alt=""
          />
          <img
            src="{{ asset('public/images/HEALTH-COVERAGE-PNG.png')}}"
            class="img-fluid d-md-none"
            alt=""
            id="left-side-img"
          />
        </div>
          
          
          
          
        
        

        <div class="col-md-6 my-2">
          <h1 class="py-3 health">HEALTH COVERAGE</h1>

          <h3 class="py-3">
            Insurance plays a significant role in reducing the financial burden
            on individuals and mitigating the risk of catastrophic medical
            expenses.By providing a safety net and ensuring access to quality
            healthcare,health insurance contributes to the overall health and
            security of individuals and communities.
          </h3>
          <div class="col-md-12">
               <a
            class="btn"
            id="contact-us"
            data-bs-toggle="modal"
            data-bs-target="#exampleModal"
            style="background-color: #0e2052;
    color: white;
    font-size: 15px;
    padding: 10px;
    font-weight: 500;
    margin-right: 1rem;"
          >
            <i class="fa-solid fa-phone"></i> CONTACT US
          </a>

            <button class="btn auto_coverage_btn">GET A QUOTE</button>
          </div>
        </div>
      </div>
    </div>
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
    <!-- Section three -->
    <div class="container-fluid" id="auto_coverage_background">
      <div class="row justify-content-center pt-3">
        <div class="col-md-12">
          <h1 class="cc pt-4">HEALTH COVERAGE</h1>
        </div>

        <div class="col-md-10">
         <div id="progressBar" class="progress-bar">
            <div class="progress-bar__steps"></div>
            <div class="progress-bar__progress" style="width: 0%"></div>
          </div>

          <form
            class="form-horizontal"
            method="POST"
            id="myform"
            action="{{ route('formsubmit') }}"
          >
            @csrf
            <fieldset id="account_information" class="">
              <div class="row d-flex justify-content-evenly py-4 px-3">
                <div class="col-md-8">
                  <h2 class="fs-title">Applicant Details:</h2>
                </div>
                <div class="col-md-4">
                  <h2 class="steps">Step 1 - 3</h2>
                </div>
              </div>

              <div class="col-md-12 px-3">
                <div class="row g-3">
                  <div class="col-md-6">
                    <label
                      for="relationship_to_applicant"
                      class="col-lg-12 control-label"
                      >Relationship to Applicant</label
                    >
                    <select
                      class="form-control" r
                      name="relationship_to_applicant"
                    required>
                       <option disabled selected value>-- select Relationship to Applicant --</option>
                      <option value="1">Self</option>
                      <option value="2">Child</option>
                      <option value="3">Spouse</option>
                      <option value="4">Grandhild</option>
                      <option value="5">GrandParent</option>
                      <option value="6">Sibling</option>
                      <option value="7">Parent</option>
                      <option value="8">Other</option>
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label for="conf_password" class="col-lg-12 control-label"
                      >Medical Condition</label
                    >
                    <select class="form-control" name="medical_condition" required>
                       <option disabled selected value>-- select Medical Condition --</option>

                      <option value="0">None</option>
                                   <option value="1">AIDS/HIV</option>
                                   <option value="2">Aneurysm</option>
                                   <option value="3">Alzheimer's Disease</option>
                                   <option value="4">Asthma</option>
                                   <option value="5">Cancer</option>
                                   <option value="6">Depression</option>
                                   <option value="7">Diabetes</option>
                                   <option value="8">Drug and/or Alcohol Abuse</option>
                                   <option value="9">Emphysema</option>
                                   <option value="10">Pregnancy</option>
                                   <option value="11">High Blood Pressure</option>
                                   <option value="12">Heart Attack</option>
                                   <option value="13">Heart Disease</option>
                                   <option value="14">Kidney Disease</option>
                                   <option value="15">Liver Disease</option>
                                   <option value="16">Mental Illness</option>
                                   <option value="17">MS</option>
                                   <option value="18">Paralysis</option>
                                   <option value="19">Pulmonary Disease</option>
                                   <option value="20">Stroke</option>
                                   <option value="21">Vascular Disease</option>
                                   <option value="22">Other / UnlistedCondition</option>
                    </select>
                  </div>
                </div>

                <div class="row g-3">
                  <div class="col-md-6">
                    <label for="password" class="col-lg-12 control-label"
                      >Height</label
                    >
                    <input
                      type="number"
                      class="form-control"
                      id="height"
                      name="height"
                      placeholder="Height" 
                      required
                    />
                  </div>
                  <div class="col-md-6">
                    <label for="conf_password" class="col-lg-12 control-label"
                      >Weight</label
                    >
                    <input
                      type="number"
                      class="form-control"
                      id="weight"
                      name="weight"
                      placeholder="Weight"
                      required
                    />
                  </div>
                </div>

                <div class="row g-3">
                  <div class="col-md-6">
                    <label for="first_name" class="col-lg-12 control-label"
                      >First Name</label
                    >
                    <input
                      type="text"
                      class="form-control"
                      id="first_name"
                      name="first_name"
                      placeholder="First Name"
                      required
                    />
                  </div>
                  <div class="col-md-6">
                    <label for="conf_password" class="col-lg-12 control-label"
                      >Last Name</label
                    >
                    <input
                      type="text"
                      class="form-control"
                      id="last_name"
                      name="last_name"
                      placeholder="Last Name"
                      required
                    />
                  </div>
                </div>

                <div class="row g-3">
                  <div class="col-md-6">
                    <label for="conf_password" class="col-lg-12 control-label"
                      >Date of Birth</label
                    >
                    <input
                      type="date"
                      class="form-control"
                      id="dob"
                      name="dob"
                      placeholder="Date of Birth"
                      required
                    />
                  </div>
                  <div class="col-md-6">
                    <label for="conf_password" class="col-lg-12 control-label"
                      >Any ongoing medical treatment</label
                    >
                    <select
                      class="form-control"
                      name="any_ongoing_medical_treatment"
                    required>
                    <option disabled selected value>-- Select Any ongoing medical treatment --</option>
                                   <option value="0">No</option>
                                   <option value="1">Yes</option>
                                   

                    
                    </select>
                  </div>
                </div>
                <div class="row g-3">
                  <div class="col-md-6">
                    <label for="conf_password" class="col-lg-12 control-label"
                      >Student</label
                    >
                    <select class="form-control" name="student" required>
                           <option disabled selected value>-- Select Student --</option>
                      <option value="1">Yes</option>
                      <option value="0">No</option>
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label for="conf_password" class="col-lg-12 control-label"
                      >Gender</label
                    >
                    <select class="form-control" name="gender" required>
                      <option disabled selected value>-- Select Gender --</option>
                      <option value="1">Male</option>
                      <option value="2">Femaale</option>
                    </select>
                  </div>
                </div>

                <div class="row g-3" style="margin-top: 30px">
                  <div class="col-md-12 text-center">
                    <p>
                      <a class="btn btn-primary next">
                        Continue
                        <i class="fa fa-arrow-right" aria-hidden="true"></i
                      ></a>
                    </p>
                  </div>
                  <!-- <p><a class="btn btn-primary next">next</a></p> -->
                </div>
              </div>
            </fieldset>

            <fieldset id="company_information" class="">
              <div class="row d-flex justify-content-evenly py-4 px-3">
                <div class="col-md-8">
                  <h2 class="fs-title">Coverage Details:</h2>
                </div>
                <div class="col-md-4">
                  <h2 class="steps">Step 2 - 3</h2>
                </div>
              </div>

              <div class="col-md-12">
                <div id="field">
                  <div id="field0">
                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Current Coverage Type</label
                        >
                        <select
                          class="form-control"
                          name="current_coverage_type" required
                        >
                         <option disabled selected value>-- Select Current Coverage Type --</option>
                          <option value="0">
                            Not Currently Insured
                          </option>
                          <option value="1">
                            State Minimum
                          </option>
                           <option value="2">
                            Standard
                          </option>
                          <option value="3">
                            Premium (Basic)
                          </option>
                          <option value="4">
                            Preferred (Superior)
                          </option>
                        </select>
                      </div>
                      <div class="col-md-6">
                        <label for="password" class="col-lg-12 control-label"
                          >Current Insurance Company</label
                        >
                        <input
                          type="text"
                          class="form-control"
                          id="current_insurance_company"
                          name="current_insurance_company"
                          placeholder="Current Insurance Company"
                          required
                        />
                      </div>
                    </div>

                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Expiration Date</label
                        >
                        <input
                          type="date"
                          name="expiration_date"
                          id="expiration_date"
                          class="form-control"
                          placeholder="Expiration Date"
                          required
                        />
                      </div>
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Insured Since</label
                        >
                        <input
                          type="date"
                          name="insured_since"
                          id="insured_since"
                          class="form-control"
                          placeholder="Insured Since"
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <!--end field0-->
                </div>
                <!--end field-->
                <!-- Button -->

                <br /><br />
              </div>
              <div class="row g-3" style="margin-top: 30px">
                <div class="col-md-12 text-center">
                  <p>
                    <a class="btn btn-primary previous" >
                      <i class="fa fa-arrow-left" aria-hidden="true"></i>
                      Previous</a
                    >
                  </p>
                </div>
                <div class="col-md-12 text-center">
                  <p>
                    <a class="btn btn-primary next">
                      Continue
                      <i class="fa fa-arrow-right" aria-hidden="true"></i
                    ></a>
                  </p>
                </div>
              </div>
            </fieldset>

            <fieldset id="personal_information" class="">
              <div class="row row d-flex justify-content-evenly py-4 px-3">
                <div class="col-md-8">
                  <h2 class="fs-title">Coverage Details:</h2>
                </div>
                <div class="col-md-4">
                  <h2 class="steps">Step 3 - 3</h2>
                </div>
              </div>

              <div class="col-md-12">
                <div id="fielda">
                  <div id="fielda0">
                    <!-- Text input-->
                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Email</label
                        >
                        <input
                          type="email"
                          name="email"
                          id="email"
                          class="form-control"
                          placeholder="Email"
                          required
                        />
                      </div>
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Phone</label
                        >
                        <input
                          type="number"
                          name="phone"
                          id="phone"
                          class="form-control"
                          placeholder="Phone"
                          required
                        />
                      </div>
                    </div>

                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Address</label
                        >
                        <input
                          type="text"
                          name="address"
                          id="address"
                          class="form-control"
                          placeholder="Address"
                          required
                        />
                      </div>
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >city</label
                        >
                        <input
                          type="text"
                          name="city"
                          id="city"
                          class="form-control"
                          placeholder="city"
                          required
                        />
                      </div>
                    </div>

                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >state</label
                        >
                        <input
                          type="text"
                          name="state"
                          id="state"
                          class="form-control"
                          placeholder="State"
                          required
                        />
                      </div>
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Zip</label
                        >
                        <input
                          type="text"
                          name="zip"
                          id="zip"
                          class="form-control"
                          placeholder="Zip"
                          required
                        />
                        <input id="leadid_token" name="universal_leadid" type="hidden" value=""/>
                      </div>
                      <br>
                      <p style="font-style: 14px">"By clicking “Get Quotes”, you provide your express written consent via electronic signature to be contacted for marketing purposes by one or more of our partner companies regarding their products and services at the phone number/email provided, including a wireless number if provided. Contact methods may include phone calls generated using automated dialing systems, artificial voice messaging, prerecorded voice messages, text messaging and/or email regardless of previous registration(s) on a federal or state Do Not Call registries or any internal opt-out/unsubscribe requests. Data rates may apply. You understand that consent is not a condition of purchase and is not required to get a quote. By clicking “Get Quotes” you confirm that you have read and agree to the Terms of Use and Privacy Policy of this website."</p>
                    </div>

                    <hr />
                  </div>
                </div>
                <br /><br />
              </div>
              <div class="row g-3" style="margin-top: 30px">
                <div class="col-md-12 text-center">
                  <p>
                    <a class="btn btn-primary previous">
                      <i class="fa fa-arrow-left" aria-hidden="true"></i>
                      Previous</a
                    >
                  </p>
                </div>
                <div class="col-md-12 text-center">
                  <p>
                    <input
                      class="btn btn-success"
                      type="submit"
                      value="submit"
                    />
                  </p>
                </div>
              </div>
            </fieldset>
          </form>
        </div>

        <!-- ===== -->
      </div>

      <!-- Section four -->
      <div class="row py-5 text-center mt-4" id="footer-back">
        <div class="col-md-12">
          <h1 class="text-light fw-bolder fs-1">
            With Cascade Coverage your future is secure
          </h1>

          <p class="text-light fs-4 fw-normal">
            We have a strong track record of meeting our financial obligation
            and <br />
            delivering on our promises to policyholder
          </p>
          <br /><br />

          <a
            class="btn"
            id="contact-us"
            data-bs-toggle="modal"
            data-bs-target="#exampleModal"
          >
            <i class="fa-solid fa-phone"></i> CONTACT US
          </a>
        </div>
      </div>
    </div>
<div
      class="modal fade"
      id="exampleModal"
      tabindex="-1"
      aria-labelledby="exampleModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog">
        <div class="modal-content" style="padding: 10px">
          <div class="modal-header">
            <h5
              class="modal-title"
              id="exampleModalLabel"
              style="color: #0e2052; font-weight: 600"
            >
              CONTACT US
            </h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div class="modal-body">
            <form class="form-horizontal"
            method="POST"
            id="myforms"
            action="{{ route('contactus') }}"
          >
            @csrf
              <div class="row g-3">
                <div class="col-md-12">
                  <label for="name" class="form-label">Name</label>
                  <input
                    type="text"
                    class="form-control"
                    id="name"
                    name="name"

                    placeholder="Enter your name"
                  />
                </div>

                <div class="col-md-12">
                  <label for="inputEmail" class="form-label">Email</label>
                  <input
                    type="email"
                    name="email"

                    class="form-control"
                    id="inputEmail"
                    placeholder="Enter your email"
                  />
                </div>

                <div class="col-12">
                  <label for="subject" class="form-label">Subject</label>
                  <input
                    type="text"
                    class="form-control"
                    name="subject"

                    id="subject"
                    placeholder="Enter your subject"
                  />
                </div>

                <div class="col-12">
                  <label for="message" class="form-label">Message</label>
                  <textarea
                    name="message"
                    id="message"
                    rows="5"
                    class="form-control"
                    id="message"
                    placeholder="Enter your message"
                  ></textarea>
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-bs-dismiss="modal"
            >
              Cancel
            </button>
        <input type="submit" class="btn btn-primary" form="myforms" />

          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap Bundle with Popper -->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>

      <script type="text/javascript">
      $(document).ready(function () {
        $.validator.addMethod(
          "usernameRegex",
          function (value, element) {
            return this.optional(element) || /^[a-zA-Z0-9]*$/i.test(value);
          },
          "Username must contain only letters, numbers"
        );

        $(".next").click(function () {
          var form = $("#myform");
          form.validate({
            errorElement: "span",
            errorClass: "help-block",
            highlight: function (element, errorClass, validClass) {
              $(element).closest(".form-group").addClass("has-error");
            },
            unhighlight: function (element, errorClass, validClass) {
              $(element).closest(".form-group").removeClass("has-error");
            },
            rules: {
              username: {
                required: true,
                usernameRegex: true,
                minlength: 6,
              },
              password: {
                required: true,
              },
              conf_password: {
                required: true,
                equalTo: "#password",
              },
              company: {
                required: true,
              },
              url: {
                required: true,
              },
              name: {
                required: true,
                minlength: 3,
              },
              email: {
                required: true,
                minlength: 3,
              },
            },
            messages: {
              username: {
                required: "Username required",
              },
              /* password: {
                required: "Password required"
              },
              conf_password: {
                required: "Password required",
                equalTo: "Password don't match"
              },*/
              name: {
                required: "Name required",
              },
              email: {
                required: "Email required",
              },
            },
          });
          if (form.valid() === true) {
            if ($("#account_information").is(":visible")) {
              current_fs = $("#account_information");
              next_fs = $("#company_information");
            } else if ($("#company_information").is(":visible")) {
              current_fs = $("#company_information");
              next_fs = $("#personal_information");
            }

            next_fs.show();
            current_fs.hide();
             if (currentStepIndex < steps.length - 1) {
              currentStepIndex++;
              updateProgressBar(currentStepIndex);
            }
          }
        });


        $(".previous").click(function () {
          if ($("#company_information").is(":visible")) {
            current_fs = $("#company_information");
            next_fs = $("#account_information");
          } else if ($("#personal_information").is(":visible")) {
            current_fs = $("#personal_information");
            next_fs = $("#company_information");
          }
          next_fs.show();
          current_fs.hide();

          if (currentStepIndex > 0) {
            currentStepIndex--;
            updateProgressBar(currentStepIndex);
          }

        });


        var progressBar = document.getElementById("progressBar");
        var stepsContainer = progressBar.querySelector(".progress-bar__steps");
        var progressBarProgress = progressBar.querySelector(
          ".progress-bar__progress"
        );

        var steps = [
          {
            icon: "fas fa-shield-virus fa-4x",
          },
          {
            icon: "fas fa-shield-virus",
          },
          {
            icon: "fas fa-shield-virus",
          }
         
        ];

        steps.forEach(function (step, index) {
          var stepElement = document.createElement("div");
          stepElement.className = "progress-bar__step";
          stepElement.innerHTML = `<i class="${step.icon}"></i>`;

          stepsContainer.appendChild(stepElement);
        });

        var currentStepIndex = 0;
        updateProgressBar(currentStepIndex);

        function updateProgressBar(currentStepIndex) {
          var stepElements = stepsContainer.querySelectorAll(
            ".progress-bar__step"
          );

          stepElements.forEach(function (stepElement, index) {
            if (index < currentStepIndex) {
              stepElement.classList.add("active");
              stepElement.innerHTML = `<i class="fas fa-check-circle fa-2x"></i>`;
            } else {
              stepElement.classList.remove("active");
              stepElement.innerHTML = `<i class="fas fa-shield-virus fa-2x"></i>`;
            }
          });

          var progressPercentage =
            (currentStepIndex / (steps.length - 1)) * 100;
          progressBarProgress.style.width = progressPercentage + "%";
        }



      });
    </script>
    <script type="text/javascript">
(function() {
var tf = document.createElement('script');
tf.type = 'text/javascript'; tf.async = true;
tf.src = ("https:" == document.location.protocol ? 'https' : 'http') + "://api.trustedform.com/trustedform.js?field=xxTrustedFormCertUrl&ping_field=xxTrustedFormPingUrl&l=" + new Date().getTime() + Math.random();
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(tf, s);
})();
</script>

<script id="LeadiDscript" type="text/javascript">
(function() {
var s = document.createElement('script');
s.id = 'LeadiDscript_campaign';
s.type = 'text/javascript';
s.async = true;
s.src = '//create.lidstatic.com/campaign/a82c0230-f287-3bcc-4681-23aecb372904.js?snippet_version=2';
var LeadiDscript = document.getElementById('LeadiDscript');
LeadiDscript.parentNode.insertBefore(s, LeadiDscript);
})();
</script>
<noscript><img src='//create.leadid.com/noscript.gif?lac=0BCB6F92-F64E-2A50-4D4A-97A78EB6B92B&lck=a82c0230-f287-3bcc-4681-23aecb372904&snippet_version=2' /></noscript>

  </body>
</html>
