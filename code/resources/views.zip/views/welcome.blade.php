<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />

    <!-- Font-awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />

    <title>Cascade</title>

    <!-- Favicon -->
    <link
      rel="apple-touch-icon"
      sizes="180x180"
      href="{{ asset('public/images/apple-touch-icon.png')}}"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="32x32"
      href="{{ asset('public/images/favicon-32x32.png')}}"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="16x16"
      href="{{ asset('public/images/favicon-16x16.png')}}"
    />
    <link rel="manifest" href="images/site.webmanifest" />
    <meta name="msapplication-TileColor" content="#da532c" />
    <meta name="theme-color" content="#ffffff" />

    <!-- External Css file -->
     <link rel="stylesheet" href="{{ asset('public/style.css')}}" />
  </head>

  <body>
    <!-- Section one Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light mb-5">
      <div class="container-fluid" style="padding: 0 4rem" id="top-nav">
        <a class="navbar-brand" href="#">
          <img src="{{ asset('public/images/logo.png')}}" alt="logo" class="logo-img img-fluid" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <!-- <a class="nav-link active" aria-current="page" href="#"></a> -->
            </li>
          </ul>
          <div class="d-flex">
            <ul class="navbar-nav me-4 mb-2 mb-lg-0">
              <li class="nav-item" style="margin-right: 10px">
                <a
                  class="nav-link active fs-5 fw-bold"
                  aria-current="page"
                  href="{{ route('auto-coverage') }}"
                  >AUTO COVERAGE</a
                >
              </li>
              <li class="nav-item">
                <a class="nav-link active fs-5 fw-bold" href="{{ route('helth-coverage') }}"
                  >HEALTH COVERAGE</a
                >
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <div class="container-fluid">
      <!-- Start container-fluid -->
      <!-- Section 2nd -->
      <div class="row d-flex justify-content-evenly">
        <div class="col-md-5">
          <img
            src="{{ asset('public/images/MAN-WITH-SHIELD.png')}}"
            alt="image"
            class="img-fluid"
          />
        </div>

        <div class="col-md-5">
          <!-- 1st card  -->
          <div class="card-box">
            <h1>
              EXPLORE THE WORLD OF INSURANCE WITH US
              <br />
              <br />
              OVER 200+ BRANDS TO CHOOSE FROM
            </h1>

            <br /><br />
            <!-- 2nd card -->
            <div class="row" id="card_box">
              <div class="col-md-6 text-center my-2">
                <a href="{{ route('auto-coverage') }}">
                  <img
                    src="{{ asset('public/images/car.png')}}"
                    alt="car"
                    class="img-fluid box-images"
                  />
                </a>
              </div>

              <div class="col-md-6 text-center my-2">
                <a href="{{ route('helth-coverage') }}">
                  <img
                    src="{{ asset('public/images/health.png')}}"
                    alt="health"
                    class="img-fluid box-images"
                  />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        class="row mt-4 pb-3 d-flex justify-content-evenly text-center"
        style="background-color: #0e2052"
      >
        <div class="col-md-12 py-5">
          <h1 class="fw-bolder fs-1 text-light">OUR BENEFITS</h1>
        </div>
        <!-- #1 -->
        <div class="col-md-5 my-4">
          <div class="row">
            <div class="col-md-3">
              <img src="{{ asset('public/images/ICON-3.png')}}" alt="" class="img-fluid" />
            </div>
            <div class="col-md-9 my-1">
              <h4 class="text-light">
                PLANS TO ALIGN <br />
                WITH YOUR <br />
                PRIORITIES.
              </h4>
            </div>
          </div>
        </div>

        <!-- #2 -->
        <div class="col-md-5 my-4">
          <div class="row">
            <div class="col-md-3">
              <img src="{{ asset('public/images/SAVING-LOGO.png')}}" alt="" class="img-fluid" />
            </div>
            <div class="col-md-9 my-1">
              <h4 class="text-light">
                TRANSPARENT <br />
                PRICING STRUCTURE <br />
                & COST-EFFECTIVE <br />
                SOLUTION.
              </h4>
            </div>
          </div>
        </div>
      </div>

      <div
        class="row d-flex pt-3 pb-5 justify-content-evenly text-center"
        style="background-color: #0e2052"
      >
        <!-- #3 -->
        <div class="col-md-5 my-4">
          <div class="row">
            <div class="col-md-3">
              <img src="{{ asset('public/images/ICON-2.png')}}" alt="" class="img-fluid" />
            </div>
            <div class="col-md-9 my-1">
              <h4 class="text-light">
                24X7 EXCEPTIONAL <br />
                CHAT SERVICES, <br />
                READILY AVAILABLE <br />
                FOR YOUR INQUERIES.
              </h4>
            </div>
          </div>
        </div>

        <!-- #4 -->
        <div class="col-md-5 my-4">
          <div class="row">
            <div class="col-md-3">
              <img src="{{ asset('public/images/AA.png')}}" alt="" class="img-fluid" />
            </div>
            <div class="col-md-9 my-1">
              <h4 class="text-light">
                HASSLE-FREE <br />
                CLAIMS, ENSURING <br />
                SEAMLESS CLAIM <br />
                PROCEDURE.
              </h4>
            </div>
          </div>
        </div>
      </div>

      <!-- Section 3rd  -->
      <div
        class="row d-flex justify-content-evenly px-2"
        style="background-color: #eff7fa; padding: 6rem 0"
      >
        <div class="col-md-5 my-3">
          <h2 class="py-4">OUR BUSINESS PHILOSOPHY</h2>

          <p>
            We are committed to building long-term relationships with our
            clients based on trust, reliability, and prompt assistance Our
            dedicated team of professionals is readily available to address your
            inquiries provide guidance, and offer support throughout your
            Insurance journey. We prioritize your satisfaction & strive to
            exceed your expectations at every interaction
          </p>
        </div>

        <div class="col-md-5 my-3">
          <img src="{{ asset('public/images/PAGE-1-PNG-2.png')}}" alt="" class="img-fluid" />
        </div>
      </div>

      <!-- Section 4th -->
      <div class="row py-5 text-center" id="footer-back">
        <div class="col-md-12">
          <h1 class="text-light fw-bolder fs-1">
            With Casecade Coverage your future is secure
          </h1>

          <p class="text-light fs-4 fw-normal">
            We have a strong track record of meeting our financial obligation
            and <br />
            delivering on our promises to policyholder
          </p>
          <br /><br />

          <a
            class="btn"
            id="contact-us"
            data-bs-toggle="modal"
            data-bs-target="#exampleModal"
          >
            <i class="fa-solid fa-phone"></i> CONTACT US
          </a>
        </div>
      </div>
      <!-- End container-fluid -->
    </div>
   <div
      class="modal fade"
      id="exampleModal"
      tabindex="-1"
      aria-labelledby="exampleModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog">
        <div class="modal-content" style="padding: 10px">
          <div class="modal-header">
            <h5
              class="modal-title"
              id="exampleModalLabel"
              style="color: #0e2052; font-weight: 600"
            >
              CONTACT US
            </h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div class="modal-body">
            <form class="form-horizontal"
            method="POST"
            id="myform"
            action="{{ route('contactus') }}"
          >
            @csrf
              <div class="row g-3">
                <div class="col-md-12">
                  <label for="name" class="form-label">Name</label>
                  <input
                    type="text"
                    class="form-control"
                    id="name"
                    name="name"
                    placeholder="Enter your name"
                  />
                </div>

                <div class="col-md-12">
                  <label for="inputEmail" class="form-label">Email</label>
                  <input
                    type="email"
                    name="email"

                    class="form-control"
                    id="inputEmail"
                    placeholder="Enter your email"
                  />
                </div>

                <div class="col-12">
                  <label for="subject" class="form-label">Subject</label>
                  <input
                    type="text"
                    name="subject"

                    class="form-control"
                    id="subject"
                    placeholder="Enter your subject"
                  />
                </div>

                <div class="col-12">
                  <label for="message" class="form-label">Message</label>
                  <textarea
                    name="message"
                    id="message"
                    rows="5"
                    class="form-control"
                    id="message"
                    placeholder="Enter your message"
                  ></textarea>
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-bs-dismiss="modal"
            >
              Cancel
            </button>
        <input type="submit" class="btn btn-primary" form="myform" />

          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap Bundle with Popper -->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
