<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />

    <!-- Font-awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />

    <title>Cascade</title>

    <!-- Favicon -->
  <link
      rel="apple-touch-icon"
      sizes="180x180"
      href="{{ asset('public/images/apple-touch-icon.png')}}"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="32x32"
      href="{{ asset('public/images/favicon-32x32.png')}}"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="16x16"
      href="{{ asset('public/images/favicon-16x16.png')}}"
    />
    <link rel="manifest" href="images/site.webmanifest" />
    <meta name="msapplication-TileColor" content="#da532c" />
    <meta name="theme-color" content="#ffffff" />
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />

    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script
      type="text/javascript"
      src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.13.1/jquery.validate.js"
    ></script>
    <script
      type="text/javascript"
      src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.13.1/additional-methods.js"
    ></script>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
    href=https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css
    rel="stylesheet">

    <!-- External Css file -->
       <link rel="stylesheet" href="{{ asset('public/style.css')}}" />

    <style>
      .progress-bar {
        width: 100%;
        height: 20px;
        background-color: #b3b3df;
        border-radius: 15px;
        position: relative;
        margin-bottom: 20px;
      }

      .progress-bar__steps {
        display: flex;
        justify-content: space-between;
        position: absolute;
        top: 50%;
        left: 0;
        transform: translateY(-50%);
        width: 100%;
        height: 100%;
        padding: 0 10px;
      }

      .progress-bar__step {
        width: 20px;
        height: 20px;
        background-color: #384fe9;
        border-radius: 50%;
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 16px;
        color: #fff;
      }

      .progress-bar__step.active {
        background-color: rgb(8, 17, 44);
      }

      .progress-bar__step i {
        font-size: 12px;
      }

      .progress-bar__progress {
        height: 100%;
        background-color: rgb(99, 117, 198);
        border-radius: 15px;
        width: 0;
        transition: width 0.8s ease;
      }

      a.btn.btn-primary.next {
        color: #fff;
        background-color: #102870;
        border-color: #0a1a4d;
      }

      a.btn.btn-primary.previous {
        color: #fff;
        background-color: #102870;
        border-color: #0a1a4d;
      }

      select.form-control {
        background-image: linear-gradient(45deg, transparent 50%, gray 50%),
          linear-gradient(135deg, gray 50%, transparent 50%),
          radial-gradient(#ddd 70%, transparent 72%);
        background-position: calc(100% - 20px) calc(1em + 2px),
          calc(100% - 15px) calc(1em + 2px), calc(100% - 0.5em) 0.5em;
        background-size: 5px 5px, 5px 5px, 1.5em 1.5em;
        background-repeat: no-repeat;
      }

      label.col-lg-12.control-label {
        text-align: left;
        margin-bottom: 14px;
        margin-top: 14px;
      }

      form#myform {
        background: #fafafaeb;
        border: 0 none;
        border-radius: 0.5rem;
        box-sizing: border-box;
        width: 100%;
        margin: 0;
        padding-bottom: 20px;
        position: relative;
      }

      label.col-lg-4.control-label {
        float: left;
      }

      #personal_information,
      #coverage_information,
      #driver_information {
        display: none;
      }

      .navbar-expand-sm .navbar-collapse {
        display: contents !important;
        flex-basis: auto;
      }

      * {
        margin: 0;
        padding: 0;
      }

      html {
        height: 100%;
      }

      #heading {
        text-transform: uppercase;
        color: #673ab7;
        font-weight: normal;
      }

      #msform {
        text-align: center;
        position: relative;
        margin-top: 20px;
      }

      #msform fieldset {
        background: #fafafaeb;
        border: 0 none;
        border-radius: 0.5rem;
        box-sizing: border-box;
        width: 100%;
        margin: 0;
        padding-bottom: 20px;
        /*stacking fieldsets above each other*/
        position: relative;
      }

      .form-card {
        text-align: left;
      }

      /*Hide all except first fieldset*/
      #msform fieldset:not(:first-of-type) {
        display: none;
      }

      .cc {
        font-size: 60px;
        color: #0e2052;
        font-weight: 700;
        text-align: center;
      }

      .fs-title {
        font-size: 23px;
        color: #000000ad !important;
        margin-bottom: 15px;
        font-weight: 500;
      }

      .steps {
        font-size: 25px;
        color: gray;
        margin-bottom: 10px;
        font-weight: normal;
        text-align: right;
      }

      #auto_coverage_background {
        background-image: url("{{ asset('image/bg-auto.jpg') }}");
        background-size: cover;
        background-repeat: no-repeat;
        padding-top: 1rem;
        max-width: 100%;
        background-size: 100% 100%;
      }
    </style>
  </head>

  <body>
    <!-- Section one Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light mb-5">
      <div class="container-fluid" style="padding: 0 4rem" id="top-nav">
        <a class="navbar-brand" href="{{ url('/') }}">
          <img src="{{ asset('public/images/logo2.png')}}" alt="logo" class="logo-img img-fluid" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <!-- <a class="nav-link active" aria-current="page" href="#"></a> -->
            </li>
          </ul>
          <div class="d-flex">
            <ul class="navbar-nav me-4 mb-2 mb-lg-0">
              <li class="nav-item" style="margin-right: 10px">
                <a
                  class="nav-link active fs-5 fw-bold"
                  aria-current="page"
                  href="{{ route('auto-coverage') }}"
                  >Auto Coverage</a
                >
              </li>
              <li class="nav-item">
                <a class="nav-link active fs-5 fw-bold" href="{{ route('helth-coverage') }}"
                  >Health Coverage</a
                >
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!-- Section two -->
    <div class="container-fluid">
      <div class="row d-flex justify-content-evenly px-3">
        <div class="col-md-5 my-2">
          <img src="{{ asset('public/images/CAR-PAGE-2.png')}}" class="img-fluid" alt="" />
        </div>

        <div class="col-md-6 my-2">
          <h1 class="aa py-3">Auto COVERAGE</h1>

          <h3 class="py-3">
            Insurance plays a significant role in reducing the financial burden
            on individuals and mitigating the risk of catastrophic medical
            expenses.By providing a safety net and ensuring access to quality
            healthcare,health insurance contributes to the overall health and
            security of individuals and communities.
          </h3>
          <div class="col-md-12">
             <a
            class="btn"
            id="contact-us"
            data-bs-toggle="modal"
            data-bs-target="#exampleModal"
            style="background-color: #0e2052;
    color: white;
    font-size: 15px;
    padding: 10px;
    font-weight: 500;
    margin-right: 1rem;"
          >
            <i class="fa-solid fa-phone"></i> CONTACT US
          </a>

            {{-- <button class="btn auto_coverage_btn">
              <i class="fa-solid fa-phone"></i> CONTACT US
            </button> --}}

            <button class="btn auto_coverage_btn">GET A QUOTE</button>
          </div>
        </div>
      </div>
    </div>
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
    <!-- Section three -->
    <div class="container-fluid" id="auto_coverage_background">
      <div class="row justify-content-center pt-3">
        <div class="col-md-12">
          <h1 class="cc">Auto COVERAGE</h1>
        </div>
        <div class="col-md-10">
          <div id="progressBar" class="progress-bar">
            <div class="progress-bar__steps"></div>
            <div class="progress-bar__progress" style="width: 0%"></div>
          </div>



           <form
            class="form-horizontal"
            method="POST"
            id="myform"
            action="{{ route('auto.autosubmit') }}"
          >
           @csrf 
            <fieldset id="account_information" class="">
              <div class="row d-flex justify-content-evenly py-4 px-3">
                <div class="col-md-8">
                  <h2 class="fs-title">
                    Just give us some information so that we can find the most
                    suitable plan for you:
                  </h2>
                </div>
                <div class="col-md-4">
                  <h2 class="steps">Step 1 - 4</h2>
                </div>
              </div>

              <div class="col-md-12 px-3">
                <div class="row g-3">
                  <div class="col-md-6">
                    <label
                      for="relationship_to_applicant"
                      class="col-lg-12 control-label"
                      >Year</label
                    >
                    <select id="dispositions_name" name="year" required class="form-control" autocomplete="off" >
                                                    <option value="">Select List</option>
                                                    @foreach($uniques as $uniquesval)
                                                    <option value="{{$uniquesval->year}}" >{{$uniquesval->year}}</option>
                                                    @endforeach
                                                </select>

                  </div>
                  <div class="col-md-6">
                    <label for="password" class="col-lg-12 control-label"
                      >Make</label
                    >
                    <select class="form-control subcategory" name="make" id="subcategory" required>
                                                            <option value="" selected>Make</option>
                                                        </select>

                  
                  </div>
                </div>

                <div class="row g-3">
                  <div class="col-md-6">
                    <label for="password" class="col-lg-12 control-label"
                      >Model</label
                    >
                    <select class="form-control" name="model" id="subcategorys" required>
                                                            <option value="" selected>Model</option>
                                                        </select>

                  </div>

                  <div class="col-md-6">
                    <label for="conf_password" class="col-lg-12 control-label"
                      >VIN</label
                    >
                    <input
                      type="text"
                      class="form-control"
                      id="vin"
                      name="vin"
                      required
                      placeholder="VIN Number"
                  minlength="17"
      maxlength="17" 
                    />
                  </div>
                </div>

                <div class="row g-3"></div>
                <br />

                <div class="row g-3" style="margin-top: 30px">
                  <br /><br />
                  <p class="col-md-12 text-center">
                    <a class="btn btn-primary next">
                      Continue
                      <i class="fa fa-arrow-right" aria-hidden="true"></i
                    ></a>
                  </p>
                </div>
              </div>
            </fieldset>

            <fieldset id="driver_information" class="">
              <div class="row d-flex justify-content-evenly py-4 px-3">
                <div class="col-md-8">
                  <h2 class="fs-title">Driver Details:</h2>
                </div>
                <div class="col-md-4">
                  <h2 class="steps">Step 2 - 4</h2>
                </div>
              </div>

              <div class="col-md-12 px-3">
                <div id="field">
                  <div id="field0">
                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Relationship To Applicant</label
                        >

                        <select
                          class="form-control"
                          name="relationship_to_applicant"
                          required
                        >
                          <option disabled selected value>
                            -- select Relationship To Applicant --
                          </option>
                          <option value="1">Self</option>
                          <option value="2">Child</option>
                          <option value="3">spouse</option>
                          <option value="4">Grand Child</option>
                          <option value="5">Grand Parent</option>
                          <option value="6">Sibling</option>
                          <option value="7">Parent</option>
                          <option value="8">other</option>
                        </select>
                      </div>
                      <div class="col-md-6">
                        <label
                          for="marital_status"
                          class="col-lg-12 control-label"
                          >Marital Status</label
                        >
                        <select
                          class="form-control"
                          name="marital_status"
                          required
                        >
                          <option disabled selected value>
                            -- select Marital Status --
                          </option>
                          <option value="1">Single</option>
                          <option value="2">married</option>
                          <option value="3">divorced</option>
                          <option value="4">Separated</option>
                          <option value="5">widowed</option>
                          <option value="6">domestic partner</option>
                        </select>
                      </div>
                    </div>

                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="marital_status"
                          class="col-lg-12 control-label"
                          >License Status</label
                        >
                        <select
                          class="form-control"
                          name="license_status"
                          required
                        >
                          <option disabled selected value>
                            -- select License Status --
                          </option>
                          <option value="1">Active</option>
                          <option value="2">International</option>
                          <option value="3">Learner</option>
                          <option value="4">probation</option>
                          <option value="5">restricted</option>
                          <option value="6">suspended</option>
                          <option value="7">temporary</option>
                        </select>
                      </div>
                      <div class="col-md-6">
                        <label
                          for="marital_status"
                          class="col-lg-12 control-label"
                          >License State</label
                        >
                        <select
                          class="form-control"
                          name="license_state"
                          required
                        >
                          <option disabled selected value>
                            -- select License State --
                          </option>
                          <option value="CA">CA</option>
                          <option value="AK">AK</option>
                          <option value="AL">AL</option>
                          <option value="AZ">AZ</option>
                          <option value="AR">AR</option>
                          <option value="AS">AS</option>
                          <option value="CO">CO</option>
                          <option value="CT">CT</option>
                          <option value="DE">DE</option>
                          <option value="DC">DC</option>
                          <option value="FL">FL</option>
                          <option value="GA">GA</option>
                          <option value="GU">GU</option>
                          <option value="HI">HI</option>
                          <option value="ID">ID</option>
                          <option value="IL">IL</option>
                          <option value="IN">IN</option>
                          <option value="IA">IA</option>
                          <option value="KS">KS</option>
                          <option value="MP">MP</option>
                          <option value="ND">ND</option>
                          <option value="NC">NC</option>
                          <option value="NY">NY</option>
                          <option value="NM">NM</option>
                          <option value="NJ">NJ</option>
                          <option value="NH">NH</option>
                          <option value="NV">NV</option>
                          <option value="NE">NE</option>
                          <option value="MT">MT</option>
                          <option value="MO">MO</option>
                          <option value="MS">MS</option>
                          <option value="MN">MN</option>
                          <option value="MI">MI</option>
                          <option value="MA">MA</option>
                          <option value="MD">MD</option>
                          <option value="ME">ME</option>
                          <option value="LA">LA</option>
                          <option value="KY">KY</option>
                          <option value="OH">OH</option>
                          <option value="OK">OK</option>
                          <option value="OR">OR</option>
                          <option value="PA">PA</option>
                          <option value="PR">PR</option>
                          <option value="RI">RI</option>
                          <option value="SC">SC</option>
                          <option value="SD">SD</option>
                          <option value="TN">TN</option>
                          <option value="TX">TX</option>
                          <option value="TT">TT</option>
                          <option value="UT">UT</option>
                          <option value="VT">VT</option>
                          <option value="VA">VA</option>
                          <option value="VI">VI</option>
                          <option value="WA">WA</option>
                          <option value="WV">WV</option>
                          <option value="WI">WI</option>
                          <option value="WY">WY</option>
                        </select>
                      </div>
                    </div>
                    <div class="row g-3">
                      <div class="col-md-6">
                        <label for="first_name" class="col-lg-12 control-label"
                          >First Name</label
                        >
                        <input
                          type="text"
                          class="form-control"
                          id="first_name_relationship"
                          required
                          name="first_name_relationship"
                          placeholder="First Name"
                        />
                      </div>
                      <div class="col-md-6">
                        <label
                          for="conf_password"
                          class="col-lg-12 control-label"
                          >Last Name</label
                        >
                        <input
                          type="text"
                          class="form-control"
                          id="last_name_relationship"
                          required
                          name="last_name_relationship"
                          placeholder="Last Name"
                        />
                      </div>
                    </div>

                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="conf_password"
                          class="col-lg-12 control-label"
                          >Date of Birth</label
                        >
                        <input
                          type="date"
                          class="form-control"
                          id="dob"
                          required
                          name="bod"
                          placeholder="Date of Birth"
                        />
                      </div>
                      <div class="col-md-6">
                        <label
                          for="conf_password"
                          class="col-lg-12 control-label"
                          >Gender</label
                        >
                        <select class="form-control" required name="gender">
                          <option value="1">Male</option>
                          <option value="2">Female</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                <br /><br />
              </div>
              <div class="row g-3" style="margin-top: 30px">
                <div class="col-md-12 text-center">
                  <p>
                    <a class="btn btn-primary previous">
                      <i class="fa fa-arrow-left" aria-hidden="true"></i>
                      Previous</a
                    >
                  </p>
                </div>
                <div class="col-md-12 text-center">
                  <p>
                    <a class="btn btn-primary next">
                      Continue
                      <i class="fa fa-arrow-right" aria-hidden="true"></i
                    ></a>
                  </p>
                </div>
              </div>
            </fieldset>

            <!-- {{-- +++++++++++++++++++++++++++++++++++++++++start++++++++++++++++++++++++++ --}} -->

            <fieldset id="coverage_information" class="">
              <div class="d-flex justify-content-evenly py-4 px-3">
                <div class="col-md-8">
                  <h2 class="fs-title">Coverage info:</h2>
                </div>
                <div class="col-md-4">
                  <h2 class="steps">Step 3 - 4</h2>
                </div>
              </div>

              <div class="col-md-12 px-3">
                <div id="field">
                  <div id="field0">
                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Coverage type</label
                        >
                        <select
                          class="form-control"
                          name="coverage_type"
                          required
                        >
                          <option disabled selected value>
                            -- Select Coverage type --
                          </option>
                          <option value="1">State Minimum</option>
                          <option value="2">Standard</option>
                          <option value="3">
                            Premium (Basic)
                          </option>
                          <option value="4">
                            Preferred (Superior)
                          </option>
                        </select>
                      </div>
                      <div class="col-md-6">
                        <label
                          for="marital_status"
                          class="col-lg-12 control-label"
                          >Uninsured Motorist cover</label
                        >
                        <select
                          class="form-control"
                          name="uninsured_motorist_cover"
                          required
                        >
                          <option disabled selected value>
                            -- Select Uninsured Motorist cover --
                          </option>
                          <option value="1">Yes</option>
                          <option value="0">No</option>
                        </select>
                      </div>
                    </div>

                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="marital_status"
                          class="col-lg-12 control-label"
                          >Current coverage type</label
                        >
                        <select
                          class="form-control"
                          name="current_coverage_type"
                          required
                        >
                          <option disabled selected value>
                            -- Select Current coverage type --
                          </option>
                          <option value="0">
                            Not currently insured
                          </option>
                          <option value="1">State Minimum</option>
                          <option value="2">Standard</option>
                          <option value="3">Premium (Basic)</option>
                          <option value="4">Preferred</option>
                        </select>
                      </div>
                      <div class="col-md-6">
                        <label
                          for="marital_status"
                          class="col-lg-12 control-label"
                          >Current Insurance Company</label
                        >
                        <select
                          class="form-control"
                          name="current_insurance_company"
                          required
                        >
                          <option disabled selected value>
                            -- Select Current Insurance Company --
                          </option>
                          <option value="21st Century Insurance">
                            21st Century Insurance
                          </option>
                          <option value="AAA Insurance Co.">
                            AAA Insurance Co.
                          </option>
                          <option value="AABCO">AABCO</option>
                          <option value="AARP">AARP</option>
                        </select>
                      </div>
                    </div>
                    <div class="row g-3">
                      <div class="col-md-6">
                        <label for="password" class="col-lg-12 control-label"
                          >Current Policy Expiry Date</label
                        >
                       <input
                          type="date"
                          class="form-control"
                          required
                          name="current_policy_expiry_date"
                          placeholder="Date of Birth"
                        />
                      </div>
                      <div class="col-md-6">
                        <label for="password" class="col-lg-12 control-label"
                          >Insured Since (date)</label
                        >
                         <input
                          type="date"
                          class="form-control"
                          required
                          name="insured_Since"
                          placeholder="Date of Birth"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <br /><br />
              </div>
              <div class="row g-3" style="margin-top: 30px">
                <div class="col-md-12 text-center">
                  <p>
                    <a class="btn btn-primary previous">
                      <i class="fa fa-arrow-left"></i> Previous</a
                    >
                  </p>
                </div>
                <div class="col-md-12 text-center">
                  <p>
                    <a class="btn btn-primary next">
                      Continue <i class="fa fa-arrow-right"></i
                    ></a>
                  </p>
                </div>
              </div>
            </fieldset>

            <!-- {{-- +++++++++++++++++++++++++++++++++++++++++End ++++++++++++++++++++++++++++ --}} -->

            <fieldset id="personal_information" class="">
              <div class="d-flex justify-content-evenly py-4 px-3">
                <div class="col-md-8">
                  <h2 class="fs-title">
                    Alright ! Seems like we have some good plans for you. Let us
                    know to contact you to discuss more about them.
                  </h2>
                </div>
                <div class="col-md-4">
                  <h2 class="steps">Step 4 - 4</h2>
                </div>
              </div>

              <div class="col-md-12 px-3">
                <div id="fielda">
                  <div id="fielda0">
                    <!-- Text input-->
                    <div class="row g-3">
                      <div class="col-md-6">
                        <label for="first_name" class="col-lg-12 control-label"
                          >First Name</label
                        >
                        <input
                          type="text"
                          class="form-control"
                          id="first_name"
                          required
                          name="first_name"
                          placeholder="First Name"
                        />
                      </div>
                      <div class="col-md-6">
                        <label for="last_name" class="col-lg-12 control-label"
                          >Last Name</label
                        >
                        <input
                          type="text"
                          class="form-control"
                          id="last_name"
                          required
                          name="last_name"
                          placeholder="Last Name"
                        />
                      </div>
                    </div>
                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Email</label
                        >
                        <input
                          type="email"
                          name="email"
                          id="email"
                          class="form-control"
                          placeholder="Email"
                          required
                        />
                      </div>
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Phone</label
                        >
                        <input
                          type="number"
                          name="phone"
                          id="phone"
                          class="form-control"
                          placeholder="Phone"
                          required
                        />
                      </div>
                    </div>

                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Address</label
                        >
                        <input
                          type="text"
                          name="address"
                          id="address"
                          class="form-control"
                          placeholder="Address"
                          required
                        />
                      </div>
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >city</label
                        >
                        <input
                          type="text"
                          name="city"
                          id="city"
                          class="form-control"
                          placeholder="city"
                          required
                        />
                      </div>
                    </div>

                    <div class="row g-3">
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >state</label
                        >
                        <input
                          type="text"
                          name="state"
                          id="state"
                          class="form-control"
                          placeholder="State"
                          required
                        />
                      </div>
                      <div class="col-md-6">
                        <label
                          for="relationship_to_applicant"
                          class="col-lg-12 control-label"
                          >Zip</label
                        >
                        <input
                          type="text"
                          name="zip"
                          id="zip"
                          class="form-control"
                          placeholder="Zip"
                          required
                        />

                         <input id="leadid_token" name="universal_leadid" type="hidden" value=""/>

                      </div>

                       <p style="font-style: 14px">"By clicking “Get Quotes”, you provide your express written consent via electronic signature to be contacted for marketing purposes by one or more of our partner companies regarding their products and services at the phone number/email provided, including a wireless number if provided. Contact methods may include phone calls generated using automated dialing systems, artificial voice messaging, prerecorded voice messages, text messaging and/or email regardless of previous registration(s) on a federal or state Do Not Call registries or any internal opt-out/unsubscribe requests. Data rates may apply. You understand that consent is not a condition of purchase and is not required to get a quote. By clicking “Get Quotes” you confirm that you have read and agree to the Terms of Use and Privacy Policy of this website."</p>
                    </div>

                    <hr />
                  </div>
                </div>
                <br /><br />
              </div>
              <div class="row g-3" style="margin-top: 30px">
                <div class="col-md-12 text-center">
                  <p>
                    <a class="btn btn-primary previous">
                      <i class="fa fa-arrow-left" aria-hidden="true"></i>
                      Previous</a
                    >
                  </p>
                </div>
                <div class="col-md-12 text-center">
                  <p>
                    <input
                      class="btn btn-success"
                      type="submit"
                      value="Submit"
                    />
                  </p>
                </div>
              </div>
            </fieldset>
            <!-- <div class="col-lg-8"> -->
          </form>
        </div>
      </div>

      <!-- Section Two -->
      <div class="row py-5 text-center mt-4" id="footer-back">
        <div class="col-md-12">
          <h1 class="text-light fw-bolder fs-1">
            With Cascade Coverage your future is secure
          </h1>

          <p class="text-light fs-4 fw-normal">
            We have a strong track record of meeting our financial obligation
            and <br />
            delivering on our promises to policyholder
          </p>
          <br /><br />

       <a
            class="btn"
            id="contact-us"
            data-bs-toggle="modal"
            data-bs-target="#exampleModal"
          >
            <i class="fa-solid fa-phone"></i> CONTACT US
          </a>
        </div>
      </div>
    </div>
 <div
      class="modal fade"
      id="exampleModal"
      tabindex="-1"
      aria-labelledby="exampleModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog">
        <div class="modal-content" style="padding: 10px">
          <div class="modal-header">
            <h5
              class="modal-title"
              id="exampleModalLabel"
              style="color: #0e2052; font-weight: 600"
            >
              CONTACT US
            </h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div class="modal-body">
            <form class="form-horizontal"
            method="POST"
            id="myforms"
            action="{{ route('contactus') }}"
          >
            @csrf
              <div class="row g-3">
                <div class="col-md-12">
                  <label for="name" class="form-label">Name</label>
                  <input
                    type="text"
                    class="form-control"
                    id="name"
                    name="name"

                    placeholder="Enter your name"
                  />
                </div>

                <div class="col-md-12">
                  <label for="inputEmail" class="form-label">Email</label>
                  <input
                    type="email"
                    name="email"

                    class="form-control"
                    id="inputEmail"
                    placeholder="Enter your email"
                  />
                </div>

                <div class="col-12">
                  <label for="subject" class="form-label">Subject</label>
                  <input
                    type="text"
                    class="form-control"
                    id="subject"
                    name="subject"

                    placeholder="Enter your subject"
                  />
                </div>

                <div class="col-12">
                  <label for="message" class="form-label">Message</label>
                  <textarea
                    name="message"
                    id="message"
                    rows="5"
                    class="form-control"
                    id="message"
                    placeholder="Enter your message"
                  ></textarea>
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-bs-dismiss="modal"
            >
              Cancel
            </button>
        <input type="submit" class="btn btn-primary" form="myforms" />

          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap Bundle with Popper -->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>

    <script type="text/javascript">
      $(document).ready(function () {
        $.validator.addMethod(
          "usernameRegex",
          function (value, element) {
            return this.optional(element) || /^[a-zA-Z0-9]*$/i.test(value);
          },
          "Username must contain only letters, numbers"
        );

        $(".next").click(function () {
          var form = $("#myform");
          form.validate({
            errorElement: "span",
            errorClass: "help-block",
            highlight: function (element, errorClass, validClass) {
              $(element).closest(".form-group").addClass("has-error");
            },
            unhighlight: function (element, errorClass, validClass) {
              $(element).closest(".form-group").removeClass("has-error");
            },
            rules: {
              username: {
                required: true,
                usernameRegex: true,
                minlength: 6,
              },
              password: {
                required: true,
              },
              conf_password: {
                required: true,
                equalTo: "#password",
              },
              company: {
                required: true,
              },
              url: {
                required: true,
              },
              name: {
                required: true,
                minlength: 3,
              },
              email: {
                required: true,
                minlength: 3,
              },
            },
            messages: {
              username: {
                required: "Username required",
              },
              /* password: {
                           required: "Password required"
                         },
                         conf_password: {
                           required: "Password required",
                           equalTo: "Password don't match"
                         },*/
              name: {
                required: "Name required",
              },
              email: {
                required: "Email required",
              },
            },
          });
          if (form.valid() === true) {
            if ($("#account_information").is(":visible")) {
              current_fs = $("#account_information");
              next_fs = $("#driver_information");
            } else if ($("#driver_information").is(":visible")) {
              current_fs = $("#driver_information");
              next_fs = $("#coverage_information");
            } else if ($("#coverage_information").is(":visible")) {
              current_fs = $("#coverage_information");
              next_fs = $("#personal_information");
            }

            next_fs.show();
            current_fs.hide();
            if (currentStepIndex < steps.length - 1) {
              currentStepIndex++;
              updateProgressBar(currentStepIndex);
            }
          }
        });

        $(".previous").click(function () {
          console.log("Previous called");
          if ($("#driver_information").is(":visible")) {
            console.log("driver page visible");
            current_fs = $("#driver_information");
            next_fs = $("#account_information");
          } else if ($("#coverage_information").is(":visible")) {
            console.log("coverage page visible");

            current_fs = $("#coverage_information");
            next_fs = $("#driver_information");
          } else if ($("#personal_information").is(":visible")) {
            console.log("personal page visible");

            current_fs = $("#personal_information");
            next_fs = $("#coverage_information");
          }
          console.log(next_fs);
          next_fs.show();
          current_fs.hide();

          if (currentStepIndex > 0) {
            currentStepIndex--;
            updateProgressBar(currentStepIndex);
          }
        });

        var progressBar = document.getElementById("progressBar");
        var stepsContainer = progressBar.querySelector(".progress-bar__steps");
        var progressBarProgress = progressBar.querySelector(
          ".progress-bar__progress"
        );

        var steps = [
          {
            icon: "fas fa-car fa-4x",
          },
          {
            icon: "fas fa-car",
          },
          {
            icon: "fas fa-car",
          },
          {
            icon: "fas fa-car",
          },
        ];

        steps.forEach(function (step, index) {
          var stepElement = document.createElement("div");
          stepElement.className = "progress-bar__step";
          stepElement.innerHTML = `<i class="${step.icon}"></i>`;

          stepsContainer.appendChild(stepElement);
        });

        var currentStepIndex = 0;
        updateProgressBar(currentStepIndex);

        function updateProgressBar(currentStepIndex) {
          var stepElements = stepsContainer.querySelectorAll(
            ".progress-bar__step"
          );

          stepElements.forEach(function (stepElement, index) {
            if (index < currentStepIndex) {
              stepElement.classList.add("active");
              stepElement.innerHTML = `<i class="fas fa-check-circle fa-2x"></i>`;
            } else {
              stepElement.classList.remove("active");
              stepElement.innerHTML = `<i class="fas fa-car fa-2x"></i>`;
            }
          });

          var progressPercentage =
            (currentStepIndex / (steps.length - 1)) * 100;
          progressBarProgress.style.width = progressPercentage + "%";
        }
      });
    </script>

      <script type="text/javascript">
  

      $(document).ready(function() {
            $('#dispositions_name').on('change', function(e) {
                var cat_id = e.target.value;
                $.ajax({

                    url: "{{ route('testingsub') }}",
                    type: "POST",
                    data: {
                      "_token": "{{ csrf_token() }}",
 
                        cat_id: cat_id
                    },
                    success: function(data) {
                        $('#subcategory').empty();
                         $('#subcategory').append("<option disabled selected value> -- select Make --                                                  </option>");
                        $.each(data.automodelmake, function(index, subcategory) {
                            $('#subcategory').append('<option value="' + subcategory
                                .make + '">' + subcategory.make + '</option>');
                        })
                    }
                })
            });
        });
</script>
<script type="text/javascript">
  

      $(document).ready(function() {
            $('.subcategory').on('change', function(e) {
                var cat_id = e.target.value;
                $.ajax({

                    url: "{{ route('testingsubsub') }}",
                    type: "POST",
                    data: {
                      "_token": "{{ csrf_token() }}",
 
                        cat_id: cat_id
                    },
                    success: function(data) {
                        $('#subcategorys').empty();
                              $('#subcategorys').append("<option disabled selected value> -- select Model --                                                  </option>");
                        $.each(data.autosubmodelmake, function(index, subcategorys) {
                            $('#subcategorys').append('<option value="' + subcategorys
                                .model + '">' + subcategorys.model + '</option>');
                        })
                    }
                })
            });
        });
</script>
<script id="LeadiDscript" type="text/javascript">
(function() {
var s = document.createElement('script');
s.id = 'LeadiDscript_campaign';
s.type = 'text/javascript';
s.async = true;
s.src = '//create.lidstatic.com/campaign/e3a85852-e86e-1be6-bd18-467615f86c96.js?snippet_version=2';
var LeadiDscript = document.getElementById('LeadiDscript');
LeadiDscript.parentNode.insertBefore(s, LeadiDscript);
})();
</script>
<noscript><img src='//create.leadid.com/noscript.gif?lac=0BCB6F92-F64E-2A50-4D4A-97A78EB6B92B&lck=e3a85852-e86e-1be6-bd18-467615f86c96&snippet_version=2' /></noscript>
<script type="text/javascript">
(function() {
var tf = document.createElement('script');
tf.type = 'text/javascript'; tf.async = true;
tf.src = ("https:" == document.location.protocol ? 'https' : 'http') + "://api.trustedform.com/trustedform.js?field=xxTrustedFormCertUrl&ping_field=xxTrustedFormPingUrl&l=" + new Date().getTime() + Math.random();
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(tf, s);
})();
</script>

  </body>
</html>
